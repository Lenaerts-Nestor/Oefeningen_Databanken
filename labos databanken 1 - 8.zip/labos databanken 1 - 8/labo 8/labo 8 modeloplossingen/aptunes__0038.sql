-- Het is niet expliciet nodig om de verschillende velden op te sommen wanneer ieder veld een waarde krijgt, maar het mag uiteraard altijd.
-- INSERT INTO LiedjeOpAlbum (Liedjes_Id, Albums_Id, Tracknummer) 
INSERT INTO LiedjeOpAlbum  
VALUES
(4, 2, "4"),
(54, 9, "2");