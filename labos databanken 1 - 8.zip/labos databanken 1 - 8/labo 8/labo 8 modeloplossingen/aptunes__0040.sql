INSERT INTO GebruikerHeeftLiedje (Gebruikers_Id, Liedjes_Id, Favoriet) 
VALUES
(2, 7, 0),
(1, 97, 1);